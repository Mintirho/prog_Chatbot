/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatbot.part2;
 import javax.swing.*;
import java.util.ArrayList;

/**
 *
 * @author RC_Student_lab
 */

public class ChatbotPart2 {

    static ArrayList<String> sentMessages = new ArrayList<>();
    static int totalMessages = 0;

    public static void main(String[] args) {
        String phoneNumber = JOptionPane.showInputDialog(null, "Enter your CellPhone Number: (+27)");
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "You must enter a phone number to register.");
            return;
        }
        if (!isValidPhoneNumber(phoneNumber)) {
            JOptionPane.showMessageDialog(null, "Invalid South African phone number. It should start with +27 followed by 9 digits.");
            return;
        }

        String username = JOptionPane.showInputDialog(null, "Enter your Username");
        if (username == null || username.trim().isEmpty() || username.length() < 5 || username.length() > 10) {
            JOptionPane.showMessageDialog(null, "Invalid username. It should be between 5 to 10 characters.");
            return;
        }

        String password = JOptionPane.showInputDialog(null, "Enter your Password");
        if (!isValidPassword(password)) {
            JOptionPane.showMessageDialog(null, "Invalid password. Must have at least 8 characters, 1 number, and 1 special character.");
            return;
        }

        JOptionPane.showMessageDialog(null, "You have been registered successfully, " + username + ".");

        String loginUser = JOptionPane.showInputDialog(null, "Enter Username to Login:");
        String loginPass = JOptionPane.showInputDialog(null, "Enter Password to Login:");

        if (!username.equals(loginUser) || !password.equals(loginPass)) {
            JOptionPane.showMessageDialog(null, "Login failed. Username or password incorrect.");
            return;
        }

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        boolean running = true;
        while (running) {
            String[] options = {"1) Send Messages", "2) Show Recently Sent Messages", "3) Quit"};
            String choice = (String) JOptionPane.showInputDialog(null, "Choose an option:", "Menu", JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (choice == null || choice.contains("3")) {
                running = false;
                break;
            } else if (choice.contains("1")) {
                String input = JOptionPane.showInputDialog(null, "How many messages do you want to send?");
                int messageCount;
                try {
                    messageCount = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid number.");
                    continue;
                }

                for (int i = 0; i < messageCount; i++) {
                    Message message = new Message();
                    String msgId = JOptionPane.showInputDialog(null, "Enter Message ID (max 10 chars):");
                    if (!message.checkMessageID(msgId)) {
                        JOptionPane.showMessageDialog(null, "Invalid Message ID.");
                        continue;
                    }

                    String recipient = JOptionPane.showInputDialog(null, "Enter recipient phone number (+27...):");
                    if (message.checkRecipientCell(recipient) == 0) {
                        JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or missing international code.");
                        continue;
                    }

                    String content = JOptionPane.showInputDialog(null, "Enter your message (Max 250 characters):");
                    if (content.length() > 250) {
                        int excess = content.length() - 250;
                        JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " + excess + ", please reduce size.");
                        continue;
                    } else {
                        JOptionPane.showMessageDialog(null, "Message ready to send.");
                    }

                    String hash = message.createMessageHash(msgId, recipient, content);
                    String action = message.SentMessage(content);

                    if (action.equals("Sent")) {
                        message.storeMessage(hash);
                        message.saveMessageToJson(msgId, recipient, content); // Save to file
                        sentMessages.add(content);
                        totalMessages++;
                    }
                }
            } else if (choice.contains("2")) {
                JOptionPane.showMessageDialog(null, String.join("\n", sentMessages));
            }
        }

        JOptionPane.showMessageDialog(null, "Thank you for using QuickChat. Goodbye!");
    }

    public static boolean isValidPhoneNumber(String number) {
        return number.matches("^\\+27\\d{9}$");
    }

    public static boolean isValidPassword(String password) {
        if (password.length() < 8) return false;

        boolean hasDigit = false, hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetter(c)) hasSpecial = true;
        }
        return hasDigit && hasSpecial;
    }
}
