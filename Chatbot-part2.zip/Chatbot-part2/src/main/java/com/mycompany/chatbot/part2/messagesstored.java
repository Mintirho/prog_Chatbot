/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatbot.part2;

/**
 *
 * @author RC_Student_lab
 */
public class messagesstored {
   
    String messageId;
    String recipient;
    String content;
    String timestamp;

    public messagesstored(String messageId, String recipient, String content, String timestamp) {
        this.messageId = messageId;
        this.recipient = recipient;
        this.content = content;
        this.timestamp = timestamp;
    }

    public String getMessageId() {
        return messageId;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getContent() {
        return content;
}
}

