/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatbot.part2;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
 import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
 
/**
 *
 * @author RC_Student_lab
 */
public class Message {
     
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final String MESSAGE_FILE = "messages.json";

    public boolean checkMessageID(String msgId) {
        return msgId != null && msgId.length() <= 10;
    }

    public int checkRecipientCell(String number) {
        if (number == null || number.length() > 13) return -1;
        return number.matches("^\\+27\\d{9}$") ? 0 : -1;
    }

    public String createMessageHash(String msgId, String recipient, String content) {
        return (msgId + recipient + content).hashCode() + "";
    }

    public String SentMessage(String content) {
        String[] options = {"Send", "Store", "Discard"};
        int choice = JOptionPane.showOptionDialog(null, content + "\nChoose action:", "Send Message",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);

        return options[choice];
    }

    public void storeMessage(String messageHash) {
        messageHashes.add(messageHash);
    }

    public String printMessages() {
        return "Sent messages:\n" + String.join("\n", messageHashes);
    }

    public int returnTotalMessages() {
        return messageHashes.size();
    }

    public void saveMessageToJson(String msgId, String recipient, String content) {
        try {
            File file = new File(MESSAGE_FILE);
            ArrayList<String> jsonMessages = new ArrayList<>();

            // If file exists, load existing JSON array entries (strip [ ] and split)
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                StringBuilder jsonBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonBuilder.append(line.trim());
                }
                reader.close();

                String rawJson = jsonBuilder.toString();
                if (rawJson.startsWith("[") && rawJson.endsWith("]")) {
                    String[] entries = rawJson.substring(1, rawJson.length() - 1).split("},\\s*\\{");
                    for (String entry : entries) {
                        entry = entry.trim();
                        if (!entry.startsWith("{")) entry = "{" + entry;
                        if (!entry.endsWith("}")) entry = entry + "}";
                        jsonMessages.add(entry);
                    }
                }
            }

            // Add the new message
            String newMessage = String.format(
                    "  {\n    \"messageId\": \"%s\",\n    \"recipient\": \"%s\",\n    \"content\": \"%s\"\n  }",
                    escape(msgId), escape(recipient), escape(content)
            );
            jsonMessages.add(newMessage);

            // Write back entire JSON array
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write("[\n");
            writer.write(String.join(",\n", jsonMessages));
            writer.write("\n]");
            writer.close();

        } catch (IOException e) {
        }
    }

    private String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
